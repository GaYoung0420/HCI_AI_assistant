active = true;
userSpeak = "";
stageState = window.localStorage.getItem("stageState");
class SpeechRecongnitionAPI {
  constructor() {
    const SpeechToText =
      window.SpeechRecongnition || window.webkitSpeechRecognition;
    this.speechApi = new SpeechToText();
    this.speechApi.continuous = true;
    this.speechApi.interimResult = true;
    this.speechApi.onresult = (event) => {
      var current = event.resultIndex;
      var transcript = event.results[current][0].transcript;
      var mobileRepeatBug =
        current == 1 && transcript == event.results[0][0].transcript;

      if (!mobileRepeatBug) {
        $("#ai-container").fadeOut(1);
        $("#user-container").fadeIn();
        $("#user-first-say").val(transcript);
        $("#user-first-say").html('" ' + $("#user-first-say").val() + ' "');
        stageState = window.localStorage.getItem("stageState");
        if (stageState == "caseA" || stageState == "caseA-task1")
          caseA(this.speechApi, transcript);
        else if (stageState == "caseB" || stageState == "caseB-task1")
          caseB(this.speechApi, transcript);
        // stageState = caseB(this.speechApi, transcript);
      }
    };
    // this.speechApi.onspeechend = function () {
    //   console.log("Speech has stopped being detected");
    //   $("#user-container").hide();
    //   $("#mic-button").removeClass("mic_buttton_active");
    //   this.speechApi.stop();
    //   active = true;
    // };
  }
  init() {
    $("#ai-container").fadeOut();
    this.speechApi.start();
    $("#mic-button").addClass("mic_buttton_active");
    active = false;
  }
  stop() {
    $("#user-container").hide();
    $("#result-dialog").hide();
    $("#mic-button").removeClass("mic_buttton_active");
    this.speechApi.stop();
    active = true;
  }
}

window.onload = function () {
  let speech = new SpeechRecongnitionAPI();

  speech.init();

  $("#mic-button").on("click", function (e) {
    stageState = window.localStorage.getItem("stageState");
    if (stageState == "caseA-fin") {
      location.href = "./caseB.html";
    } else if (active) {
      speech.init();
    } else {
      speech.stop();
    }
  });
};

function caseA(api, userSpeak) {
  console.log(userSpeak);
  console.log("stageState:" + stageState);

  if (
    stageState == "caseA" &&
    userSpeak.indexOf("가영") != -1 &&
    userSpeak.indexOf("문자") != -1
  ) {
    answerContain(
      userSpeak,
      document.querySelector("#caseA-1"),
      "가영에게 어떤 내용으로 문자를 보낼까요?"
    );
    window.localStorage.setItem("stageState", "caseA-task1");
  } else if (
    stageState == "caseA-task1" &&
    (userSpeak.indexOf("뭐해") != -1 || userSpeak.indexOf("뭐") != -1)
  ) {
    resultDialog(
      userSpeak,
      document.querySelector("#finish"),
      '가영이에게 "뭐해"라고 문자를 보냈어요',
      "010-1234-5678"
    );
    $("#mic-button").removeClass("mic_buttton_active");
    api.stop();
    active = true;
    setTimeout(() => {
      document.querySelector("#caseA-fin").muted = false;
      document.querySelector("#caseA-fin").play();
    }, 6000);
    window.localStorage.setItem("stageState", "caseA-fin");
  } else {
    answerContain(
      userSpeak,
      document.querySelector("#error"),
      "무슨 말인지 못 알아들었어요."
    );
  }
}

function caseB(api, userSpeak) {
  if (
    stageState == "caseB" &&
    userSpeak.indexOf("가영") != -1 &&
    userSpeak.indexOf("문자") != -1
  ) {
    $("#checkBtn").show();
    answerContain(
      userSpeak,
      document.querySelector("#caseA-1"),
      "가영에게 어떤 내용으로 문자를 보낼까요?"
    );
    window.localStorage.setItem("stageState", "caseB-task1");
  } else if (
    stageState == "caseB-task1" &&
    (userSpeak.indexOf("뭐해") != -1 || userSpeak.indexOf("뭐") != -1)
  ) {
    resultDialog(
      userSpeak,
      document.querySelector("#caseB-2"),
      '가영(010-1234-5678)에게 "뭐해"라고 문자를 보낼까요?',
      "010-1234-5678"
    );
    window.localStorage.setItem("stageState", "caseB-task2");
  } else {
    answerContain(
      userSpeak,
      document.querySelector("#error"),
      "무슨 말인지 못 알아들었어요."
    );
  }
}

function answerContain(userSpeak, audio, treeS) {
  $("#user-container").delay(1000).fadeOut();
  $("#ai-container").delay(2000).fadeIn();

  setTimeout(() => {
    audio.muted = false;
    audio.play();
  }, 2000);

  $("#user-say").html("> " + userSpeak);
  $("#tree-say").html(treeS);
}

function resultDialog(userSpeak, audio, treeS, phoneNum) {
  $("#user-container").delay(1000).fadeOut();
  $("#result-dialog").delay(2000).fadeIn();
  setTimeout(() => {
    audio.muted = false;
    audio.play();
  }, 2000);
  $("#phone-num").val(phoneNum);
  $("#phone-num").html(phoneNum);
  $("#user-say-result").html("> " + userSpeak);
  $("#tree-say-result").html(treeS);
}
